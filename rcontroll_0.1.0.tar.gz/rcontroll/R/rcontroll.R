#' rcontroll
#'
#' Function and code to manage and use indivdual-based and spatially-explicit
#' forest growth model TROLL.
#'
#' @section Section functions: \describe{
#' To define.
#' }
#'
#' @docType package
#' @name rcontroll
NULL
# > NULL
