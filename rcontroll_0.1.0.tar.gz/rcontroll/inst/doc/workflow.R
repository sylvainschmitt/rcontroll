## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.height = 8,
  fig.width = 8
)

## ----libs---------------------------------------------------------------------
library(dplyr)
library(tidyr)
library(rcontroll)
iters <- 10

## ----genPar-------------------------------------------------------------------
generate_parameters(cols = 400, rows = 400) %>% 
  head()

## ----datasim------------------------------------------------------------------
data("TROLLv3_input")
data("TROLLv3_species")
data("TROLLv3_climatedaytime12")
data("TROLLv3_climatedaytime365")
data("TROLLv3_daytimevar")
TROLLv3_input$value[5] <- iters # iterations

## ----fullsim------------------------------------------------------------------
sim <- troll(name = "test",
             # path = "./",
             full = TRUE,
             abc = FALSE, 
             random = TRUE,
             global = TROLLv3_input,
             species = TROLLv3_species,
             climate = TROLLv3_climatedaytime12,
             daily = TROLLv3_daytimevar)
sim

## ----fullsimG1----------------------------------------------------------------
autoplot(sim, 
         what = "ecosystem", 
         variables = c("abund", "agb"), 
         species = "total")

## ----fullsimG2----------------------------------------------------------------
autoplot(sim, what = "final pattern")

## ----reducedsim---------------------------------------------------------------
sim <- troll(name = "test1",
             overwrite = TRUE,   
             # path = "./",
             full = FALSE,
             abc = FALSE, 
             random = TRUE,
             global = TROLLv3_input,
             species = TROLLv3_species,
             climate = TROLLv3_climatedaytime12,
             daily = TROLLv3_daytimevar)
sim

## ----reducedsimG1-------------------------------------------------------------
autoplot(sim, 
         what = "ecosystem", 
         variables = c("N", "AGB"), 
         species = "total")

## ----datastack----------------------------------------------------------------
library(rcontroll)
data("TROLLv3_input")
data("TROLLv3_species")
data("TROLLv3_climatedaytime12")
data("TROLLv3_climatedaytime365")
data("TROLLv3_daytimevar")
TROLLv3_input$value[5] <- iters # iterations
TROLLv3_input_stack <- TROLLv3_input %>% 
  mutate(simulation = list(c("seed50000", "seed500"))) %>% 
  unnest(simulation)
TROLLv3_input_stack[62,2] <- 500 # Cseedrain

## ----fullstack----------------------------------------------------------------
sim <- stack(name = "test3", 
             simulations = c("seed50000", "seed500"),
             # path = "/home/sylvain/Documents/ECOFOG/rcontroll",
             full = TRUE,
             abc = FALSE,
             random = TRUE,
             global = TROLLv3_input_stack,
             species = TROLLv3_species,
             climate = TROLLv3_climatedaytime12,
             daily = TROLLv3_daytimevar)
sim

## ----fullstackG1--------------------------------------------------------------
autoplot(sim, 
         what = "ecosystem", 
         variables = c("abund", "agb"), 
         species = "total")

## ----fullstackG2--------------------------------------------------------------
autoplot(sim, what = "final pattern")

## ----reducedstack-------------------------------------------------------------
sim <- stack(name = "test",
             simulations = c("seed50000", "seed500"),
             # path = "/home/sylvain/Documents/ECOFOG/rcontroll",
             full = FALSE,
             abc = FALSE, 
             random = TRUE,
             global = TROLLv3_input_stack,
             species = TROLLv3_species,
             climate = TROLLv3_climatedaytime12,
             daily = TROLLv3_daytimevar)
sim

## ----reducedstackG1-----------------------------------------------------------
autoplot(sim, 
         what = "ecosystem", 
         variables = c("N", "AGB"), 
         species = "total")

